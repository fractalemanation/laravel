<?php $__env->startSection('content'); ?>
<div class="container">
	<?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<div class="row">
		<div class="col-sm-12">
			<h2><a href="<?php echo e(route('article', $article->slug)); ?>"><?php echo e($article->title); ?></a></h2>
			<p><?php echo $article->description_short; ?></p>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<h2 class="text-center">Пусто</h2>
	<?php endif; ?>
	<center><?php echo e($articles->links()); ?></center>
</div>

<h1>Загрузка файла вариант 1</h1>
<form method="post" enctype="multipart/form-data" action="<?php echo e(route('image.upload')); ?>">
	<?php echo e(csrf_field()); ?>

	<div class="form-group">
		<input type="file" name="image">
	</div>
	<button class="btn btn-default" type="submit">Загрузка</button>
</form>
<?php if(isset($path)): ?>
<br><img class="img-responsive" src="<?php echo e(asset('/storage/'.$path)); ?>">
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>