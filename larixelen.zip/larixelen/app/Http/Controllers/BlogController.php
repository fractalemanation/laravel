<?php

namespace App\Http\Controllers;

use App\Article;
use App\Category;
use App\Download;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function category($slug) {

    	$category = Category::where('slug', $slug)->first();

    	return view('blog.category', [
    		'category' => $category,
    		'articles' => $category->articles()->where('published', 1)->paginate(12)
    	]);
    }

    public function article($slug) {
    	return view('blog.article', [
    		'article' => Article::with('downloads')->where('slug', $slug)->first()
    	]);
    }

    public function fileDownload(Download $download){
        return response()->download(storage_path('app/public/'. $download->path));
    }
}
