<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row text-center">
        <div class="col-sm-3">
            <div class="jumbotron">
                <h3><span class="badge badge-primary p-2">Категорий <?php echo e($categoryCount); ?></span></h3>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="jumbotron">
                <h3><span class="badge badge-primary p-2">Материалов <?php echo e($articleCount); ?></span></h3>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="jumbotron">
                <h3><span class="badge badge-primary p-2">Посетителей 0</span></h3>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="jumbotron">
                <h3><span class="badge badge-primary p-2">Сегодня 0</span></h3>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6">
            <a class="btn btn-block btn-dark" href="<?php echo e(route('admin.category.create')); ?>">Создать категорию</a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="list-group-item" href="<?php echo e(route('admin.category.edit', $category)); ?>">
                    <h4 class="list-group-item-heading"><?php echo e($category->title); ?></h4>
                    <p class="list-group-item-text">
                        <?php echo e($category->articles()->count()); ?>

                    </p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-sm-6">
            <a class="btn btn-block btn-dark" href="<?php echo e(route('admin.article.create')); ?>">Создать материал</a>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="list-group-item" href="<?php echo e(route('admin.article.edit', $article)); ?>">
                    <h4 class="list-group-item-heading"><?php echo e($article->title); ?></h4>
                    <p class="list-group-item-text">
                        <?php echo e($article->categories()->pluck('title')->implode(', ')); ?>

                    </p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>