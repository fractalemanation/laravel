<h2><?php echo e($title); ?></h2>
<nav aria-label="breadcrumb">
	<ol class="breadcrumb">
  		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e($parent); ?></a></li>
  		<li class="breadcrumb-item active"><?php echo e($active); ?></li>
	</ol>
</nav>
