<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <option value="<?php echo e($categoryList->id ?? ''); ?>"

        <?php if(isset($category->id)): ?>

            <?php if($category->parent_id == $categoryList->id): ?>
                selected=""
            <?php endif; ?>

            <?php if($category->id == $categoryList->id): ?>
                hidden=""
            <?php endif; ?>

        <?php endif; ?>

    >
    <?php echo e($delimiter ?? ''); ?><?php echo e($categoryList->title ?? ''); ?>

    </option>

    <?php if(isset($categoryList->children)): ?>

        <?php echo $__env->make('admin.category._categories', [
            'categories' => $categoryList->children,
            'delimiter'  => ' - ' . $delimiter
        ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
