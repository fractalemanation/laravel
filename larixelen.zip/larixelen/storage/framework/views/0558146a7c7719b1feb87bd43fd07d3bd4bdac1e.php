<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <option value="<?php echo e($category->id ?? ""); ?>"

        <?php if(isset($article->id)): ?>

          <?php if( $article->categories->contains('id', $category->id) ): ?> 
             selected="selected"
          <?php endif; ?>

        <?php endif; ?>
    >
    <?php echo $delimiter ?? ''; ?><?php echo e($category->title ?? ''); ?>

    </option>

    <?php if(isset($category->children)): ?>

        <?php echo $__env->make('admin.article._categories', [
            'categories' => $category->children,
            'delimiter'  => ' - ' . $delimiter
        ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
