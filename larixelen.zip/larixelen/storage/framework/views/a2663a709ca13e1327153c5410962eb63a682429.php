<?php $__env->startSection('title', $article->meta_title); ?>
<?php $__env->startSection('meta_keyword', $article->meta_keyword); ?>
<?php $__env->startSection('meta_description', $article->meta_description); ?>

<?php $__env->startSection('content'); ?>

	<div class="container">

		<div class="card">
		  	<div class="card-body">
			    <h1 class="card-title text-center"><?php echo e($article->title); ?></h1>
			    <h6 class="card-subtitle mb-2 text-muted text-center">
			    	<i class="far fa-calendar-alt"></i>
			    	<?php echo e($article->created_at->format('d.m.Y H:i')); ?>

			    	(<?php echo e($article->created_at->diffForHumans()); ?>)
			    </h6>
			    <p class="card-text"><?php echo $article->description; ?></p>
			    <?php $__currentLoopData = $article->downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><a href="<?php echo e(route('download', $download)); ?>" title=""><?php echo e($download->title ?? ''); ?></a></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  	</div>
		</div>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>