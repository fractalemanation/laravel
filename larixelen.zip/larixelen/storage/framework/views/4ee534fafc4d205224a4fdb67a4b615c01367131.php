<?php $__env->startSection('content'); ?>

<div class="container">

    <?php $__env->startComponent('admin.components.breadcrumb'); ?>
        <?php $__env->slot('title'); ?> Список пользователей <?php $__env->endSlot(); ?>
        <?php $__env->slot('parent'); ?> Главная <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Пользователи <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <a href="<?php echo e(route('admin.user_managment.user.create')); ?>" class="btn btn-primary mb-2"><i class="far fa-plus-square"></i> Создать</a>
  
    <table class="table table-striped table-borderless">
        <thead class="thead-dark">
            <th>Имя</th>
            <th>Email</th>
            <th class="text-right">Действие</th>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td class="text-right">
                    <form onsubmit="if(confirm('Удалить?')){ return true }else{ return false }" action="<?php echo e(route('admin.user_managment.user.destroy', $user)); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                    
                        <a class="btn btn-primary" href="<?php echo e(route('admin.user_managment.user.edit', $user)); ?>"><i class="fa fa-edit"></i></a>

                        <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="text-center"><h2>Данные отсутствуют</h2></td>
            </tr>
        <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3">
                    <?php echo e($users->links()); ?>

                </td>
            </tr>
        </tfoot>
    </table>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>