<?php $__env->startSection('content'); ?>

<div class="container">

    <?php $__env->startComponent('admin.components.breadcrumb'); ?>
        <?php $__env->slot('title'); ?> Список новостей <?php $__env->endSlot(); ?>
        <?php $__env->slot('parent'); ?> Главная <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Новости <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <a href="<?php echo e(route('admin.article.create')); ?>" class="btn btn-primary mb-2"><i class="far fa-plus-square"></i> Создать</a>

    <table class="table table-striped table-borderless">
        <thead class="thead-dark">
            <th>Наименование</th>
            <th class="text-center">Публикация</th>
            <th class="text-right">Действие</th>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($article->title); ?></td>
                <td class="text-center">
                    <form id="published-form-<?php echo e($article->id ?? ''); ?>" class="form-horizontal" action="<?php echo e(route('admin.article.update', $article)); ?>" method="post">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        
                        <?php if($article->published): ?>
                            <i class="far fa-check-square fa-2x text-info" onclick="event.preventDefault();
                                   document.getElementById('published-form-<?php echo e($article->id); ?>').submit();"></i>
                            <input type="hidden" name="published" value="0">
                        <?php else: ?>
                            <i class="fas fa-times fa-2x text-danger" onclick="event.preventDefault();
                                   document.getElementById('published-form-<?php echo e($article->id); ?>').submit();"></i>
                            <input type="hidden" name="published" value="1">
                        <?php endif; ?>
                    </form>
                </td>
                <td class="text-right">
                    <form onsubmit="if(confirm('Удалить?')){ return true }else{ return false }" action="<?php echo e(route('admin.article.destroy', $article)); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                    
                        <a class="btn btn-primary" href="<?php echo e(route('admin.article.edit', $article)); ?>"><i class="fa fa-edit"></i></a>

                        <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="text-center"><h2>Данные отсутствуют</h2></td>
            </tr>
        <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3">
                    <?php echo e($articles->links()); ?>

                </td>
            </tr>
        </tfoot>
    </table>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>