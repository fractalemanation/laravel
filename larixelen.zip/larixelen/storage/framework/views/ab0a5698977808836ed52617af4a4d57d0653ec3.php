<?php $__env->startSection('title', $category->title . " - DKA-DEVELOP"); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="container">
		
		<div class="row">
			<?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				
				<div class="col-sm-4 mb-2">

					<div class="card">
					  	<div class="card-body">
						    <h4 class="card-title text-center"><a href="<?php echo e(route('article', $article->slug)); ?>"><?php echo e($article->title); ?></a></h4>
						    <h6 class="card-subtitle mb-2 text-muted text-center">
						    	<i class="far fa-calendar-alt"></i>
						    	<?php echo e($article->created_at->format('d.m.Y H:i')); ?>

						    	(<?php echo e($article->created_at->diffForHumans()); ?>)
						    </h6>
						    <p class="card-text"><?php echo $article->description_short; ?></p>
					  	</div>
					</div>

				</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				
				<div class="col-sm-12">

					<div class="jumbotron jumbotron-fluid text-center">
						<div class="container-fluid">
						  	<h1 class="display-4">Статьи отсутствуют</h1>
						  	<p class="lead">Вы можете вернуться позже и мы обязательно заполним данный раздел.</p>
						  	<hr class="my-4">
						  	<a class="btn btn-primary btn-lg" href="<?php echo e(url('')); ?>" role="button">Перейти на главную</a>
					  	</div>
					</div>

				</div>

			<?php endif; ?>
		</div>
		
		<?php if($articles->hasMorePages()): ?>
			<div class="card mt-2">
			  	<div class="card-header">
				    <?php echo e($articles->links()); ?>

			  	</div>
			</div>
		<?php endif; ?>
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>