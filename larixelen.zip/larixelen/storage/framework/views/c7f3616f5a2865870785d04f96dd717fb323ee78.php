<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($category->children->where('published', 1)->count()): ?>
        <li class="nav-item dropdown">
            <a href="<?php echo e(route('category', $category->slug)); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                <?php echo e($category->title); ?>

            </a>
            <div class="dropdown-menu">
                <?php echo $__env->make('layouts._menu', [
                    'categories' => $category->children,
                    'isChild' => true
                ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </li>
    <?php else: ?>

        <?php if(isset($isChild)): ?>
            <a class="nav-link" href="<?php echo e(route('category', $category->slug)); ?>"><?php echo e($category->title); ?></a>
            <?php continue; ?>
        <?php endif; ?>  

        <li class="nav-item">             
            <a class="nav-link" href="<?php echo e(route('category', $category->slug)); ?>"><?php echo e($category->title); ?></a>
        </li>
    <?php endif; ?>
    
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
