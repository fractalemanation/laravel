## About Blog
About Blog<br />
Ready blog for used. Created with use Laravel 5.7.

## О блоге
Готовый блог для использования. Создан на основе Laravel 5.7.

## Install (Установка)
git clone git@github.com:dka-develop/dka-blog-new.git<br />

composer install<br />
yarn or npm install<br />
php artisan migrate<br />
php artisan db:seed<br />
php artisan key:generate<br />

php artisan serve<br />

login: admin@site.ru<br />
pass: admin

## License
Licensed under the [MIT license](http://opensource.org/licenses/MIT).
