@extends('layouts.app')

@section('content')
<!--<div class="main-block container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="calculator-block col-md-4 text-center">
                <h1 class="title-calculator-main col-md-12">УБОРКА</h1>
                @foreach ($сalculators as $calculator)
	                <div>
	                    <button class="btn btn-default btn-calculator-type col-xs-12 col-md-4 text-uppercase" v-on:click="show = {{$calculator->id}}">{{$calculator->title}}</button>
	                </div>
	            @endforeach
	            @foreach ($сalculators as $calculator)
	                <div>
	                    <div v-if="show === {{$calculator->id}}">
	                        <h1 class="title-calculator col-md-12 text-uppercase">{{$calculator->title}}</h1>
	                    </div>
	                </div>
	            @endforeach
            </div>
        </div>
    </div>
</div>
@foreach ($сalculators as $calculator)
  {{$calculator->title}}
  @isset ($calculator->fields)
      @foreach ($calculator->fields as $field)
        {{$field->title}}
      @endforeach
  @endisset
@endforeach-->
<div id="congratulations" class="modal fade" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button class="close" data-dismiss="modal">х</button>
        <h4 class="modal-title text-center">{{$data[3]->description}}</h4>
      </div>
      <div class="modal-body text-center">
        <h3>{{$data[4]->description}}</h3>
      </div>
      <div class="modal-footer">
        <button class="btn btn-default btn-block" data-dismiss="modal">{{$data[5]->description}}</button>
      </div>
    </div>
  </div>
</div>
<main-component :calculators="{{$сalculators}}"></main-component>
<div class="container general-text">
  <h1 class="text-center">{{$data[0]->description}}</h1>
	<p class="text-center">{{$data[1]->description}}</p>
</div>
<div class="container service text-center">
    <h1>{{$data[2]->description}}</h1>
		<div class="row services">
      @include('layouts.services')
    </div>
</div>
@endsection