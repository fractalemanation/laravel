<?php

namespace App\Http\Controllers;

use App\Calculator;
use App\Field;
use App\Service;
use App\General;
use Illuminate\Http\Request;
use Mail;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home', [
            'сalculators' => Calculator::with('fields')->get(),
            'services' => Service::with('children')->where('parent_id', 0)->get(),
            'data' => General::where('type', 'main')->get()
        ]);
    }
    public function send(Request $request) {
        Mail::send(['html' => 'mail'], ['data' => $request->all()], function ($message) {
            $message->from('danyy385@gmail.com', 'iClean');
            $message->to('danyy385@gmail.com', 'iClean')->subject('Заказ');
        });//1-ый аргумент - имя файла в котором будет текст для сообщения, 2-ой аргумент это массив данных предоставляемых в представлении, 3-ий аргумент это замыкающая функция получающая экземпляр сообщения и позволяющая настроить параметры сообщения (получатель, тема письма, отправитель)
        /*$message = "";
        foreach ($request->all() as $key => $value) {
            if ($value) {
                if ($key == 'phone')
                    $message .= "Номер телефона: {$value}\n";
                else if ($key == 'address')
                    $message .= "Адрес: {$value}\n";
                else if ($key == 'name')
                    $message .= "Имя: {$value}\n";
                else if ($key == 'type')
                    $message .= "Уборка: {$value}\n";
                else if ($key == 'room')
                    $message .= "Количество комнат: {$value}\n";
                else if ($key == 'bathroom')
                    $message .= "Количество санузлов: {$value}\n";
                else if ($key == 'window')
                    $message .= "Количество окон: {$value}\n";
                else if ($key == 'balcony')
                    $message .= "Количество балконов: {$value}\n";
                else if ($key == 'kitchen')
                    $message .= "Кухня\n";
                else if ($key == 'vacuum')
                    $message .= "Пылесос\n";
                else if ($key == 'side')
                    $message .= "Окна с двух сторон\n";
                else if ($key == 'sill')
                    $message .= "Подоконники\n";
                else if ($key == 'frame')
                    $message .= "Рамки\n";
                else if ($key == 'price')
                    $message .= "Цена: {$value}";
            }
        }
        mail('danyy385@gmail.com', 'Заказ', $message, 'From: mail@cleaninger.zzz.com.ua');*/
    }
}
