<?php $__currentLoopData = $rubrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rubric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($rubric->children->count()): ?>
        <?php if($rubric->parent_id == 0): ?>
            <div class="col-md-4">
                <h2><?php echo e($rubric->title ?? ''); ?></h2>
                <?php echo $__env->make('layouts.rubric', ['rubrics' => $rubric->children, 'is_child' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        <?php else: ?>
            <h3><?php echo e($rubric->title ?? ''); ?></h3>
            <ul class="col-md-12">
                <?php echo $__env->make('layouts.rubric', ['rubrics' => $rubric->children, 'is_child' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </ul>
        <?php endif; ?>
    <?php else: ?>
        <?php if(isset($is_child)): ?>
            <li><?php echo e($rubric->title ?? ''); ?></li>
            <?php continue; ?>
        <?php endif; ?>
        <div class="col-md-4"><h2><?php echo e($rubric->title ?? ''); ?></h2></div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>