@foreach ($categories as $category)
    @if ($category->children->count())
        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">{{$category->title ?? ''}}<span class="caret"></span></a>
            <ul class="dropdown-menu">
                <li><a href="{{route('category.edit', $category)}}">{{$category->title ?? ''}}</a></li>
                @include('layouts._menu', ['categories' => $category->children, 'is_child' => true])
            </ul>
        </li>
    @else
        @isset($is_child)
            <li><a href="{{route('category.edit', $category)}}">{{$category->title ?? ''}}</a></li>
            @continue
        @endisset
        <li class="dropdown"><a href="{{route('category.edit', $category)}}">{{$category->title ?? ''}}</a></li>
    @endif
@endforeach