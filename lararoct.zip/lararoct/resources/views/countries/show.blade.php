@extends('layouts.app')

@section('content')
	<div class="container">
		<a href="{{route('country.index')}}" class="btn btn-primary">Назад</a>
		<hr>
		<h1>{{$country->name or ''}}</h1>
		<small>Кол-во советов: {{$country->advices->count()}}</small>
		@forelse ($country->advices as $advice)
			<div>{{$advice->text}}</div>
		@empty
			<div>Без комментариев</div>
		@endforelse
	</div>
	</div>
@endsection