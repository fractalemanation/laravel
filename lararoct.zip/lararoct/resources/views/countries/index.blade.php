@extends('layouts.app')

@section('content')
	<div class="container">
		<a href="{{route('country.create')}}" class="btn btn-primary">Создать</a>
		<a href="{{route('note.index')}}" class="btn btn-default">Заметки</a>
		
		<hr>

		<table class="footable table table-stripped toggle-arrow-tiny" data-page-size="15">
		  <thead>
		    <tr>
		      <th data-toggle="true">Наименование</th>
		      <th data-hide="phone">Заметки</th>
		      <th class="text-right" data-sort-ignore="true">Действие</th>
		    </tr>
		  </thead>
		  <tbody>
		    @forelse ($countries as $country)
		      <tr>
		        <td>{{ $country->name }}</td>
		        <td>{{$country->notes()->pluck('title')->implode(', ')}}</td><!--pluck() - извлекает все значения по заданому ключу-->
		        <td class="text-right">
		          <form onsubmit="if(confirm('Удалить?')){ return true }else{ return false }" action="{{route('country.destroy', $country)}}" method="post">
		            <input type="hidden" name="_method" value="DELETE">
		            {{ csrf_field() }}
		            <div class="btn-group">
		            	<a class="btn btn-secondary" href="{{route('country.show', $country)}}">Просмотр</a>
		              <a class="btn btn-primary" href="{{route('country.edit', $country)}}">Редактировать</a>
		              <button type="submit" class="btn btn-danger">Удалить</button>
		            </div>
		          </form>
		        </td>
		      </tr>
		    @empty
		      <tr>
		        <td colspan="5" class="text-center">
		          <h2 class="ui center aligned icon header" class="center aligned">
		            <i class="circular database icon"></i>
		            Данные отсутствуют
		          </h2>
		        </td>
		      </tr>
		    @endforelse

		  </tbody>
		</table>
	</div>
@endsection