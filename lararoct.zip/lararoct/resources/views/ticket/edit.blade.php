@extends('layouts.app')

@section('content')
	<div class="container">
		<form action="{{route('ticket.update', $ticket)}}" method="post">
			{{method_field('PUT')}}
			{{csrf_field()}}
			@include('ticket._form')
		</form>
	</div>
@endsection