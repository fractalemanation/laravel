@extends('layouts.app')
@section('content')
	<div class="container">
		<a class="btn btn-primary" href="{{route('ticket.create')}}">Создать</a>
		<hr>
		<table class="table">
			<thead>
				<tr>
					<th>Наименование</th>
					<th class="text-right">Действие</th>
				</tr>
			</thead>
			<tbody>
				@forelse ($tickets as $ticket)
					<tr>
						<td>{{$ticket->title ?? ''}}</td>
						<td class="text-right">
							<a class="btn btn-primary" href="{{route('ticket.edit', $ticket)}}">Редактировать</a>
						</td>
					</tr>
				@empty
					<tr>
						<td colspan="2">
							<h1 class="text-center">Категории отсутствуют</h1>
						</td>
					</tr>
				@endforelse
			</tbody>
		</table>
	</div>
@endsection