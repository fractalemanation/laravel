@extends('layouts.app')

@section('content')
	<div class="container">
		<form action="{{route('ticket.store')}}" method="post">
			{{ csrf_field() }}
			@include('ticket._form')
		</form>
	</div>
@endsection