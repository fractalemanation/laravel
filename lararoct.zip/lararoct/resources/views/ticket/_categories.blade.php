@foreach ($categories as $categoryItem)
	<option value="{{$categoryItem->id ?? ''}}"
		@isset ($ticket->id)
			@if ($ticket->categories->contains('id', $categoryItem->id))
				selected="selected"
			@endif
		@endisset
	>{{$delimiter ?? ''}}{{$categoryItem->title ?? ''}}</option>
	@isset ($categoryItem->children)
		@include('ticket._categories', [
			'categories' => $categoryItem->children,
			'delimiter' => ' - '.$delimiter
		])<!--рекурсия, Только вложеные категории в данную категорию-->
	@endisset
@endforeach

<!--@foreach ($ticket->categories as $categoryTicket)
	@if ($categoryItem->id == $categoryTicket->id)
		selected="selected"
	@endif
@endforeach-->