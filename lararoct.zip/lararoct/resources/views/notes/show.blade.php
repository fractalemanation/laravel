@extends('layouts.app')

@section('content')
	<div class="container">
		<a href="{{route('note.index')}}" class="btn btn-primary">Назад</a>
		<hr>
		<h1>{{$note->title or ''}}</h1>
		@foreach ($countries as $country)
			@if ($note->country_id == $country->id)
				{{$country->name}}
			@endif
		@endforeach
		<hr>
		@forelse ($note->advices as $advice)
			<div class="alert alert-primary" role="alert">
				{{$advice->text or ''}}
				<p class="mb-0">
					<a class="btn btn-primary" href="{{route('advice.edit', $advice)}}">Редактировать</a>
				</p>
			</div>
		@empty
			<h3 class="text-center">Комментариев нет</h3>
		@endforelse
		<form class="form-horizontal" action="{{route('advice.store')}}" method="post">
			<input type="hidden" name="note_id" value="{{$note->id or ''}}">
			{{csrf_field()}}
			<fieldset class="form-horizontal">
				<div class="form-group">
					<label class="col-sm-1 control-label">Комментарий:</label>
					<div class="col-sm-12">
						<textarea name="text" class="form-control"></textarea>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-4">
						<button class="btn btn-primary" type="submit">Опубликовать</button>
					</div>
				</div>
			</fieldset>
		</form>
	</div>
@endsection