@extends('layouts.app')

@section('content')
	<div class="container">
		<form action="{{route('category.update', $category)}}" method="post">
			{{method_field('PUT')}}
			{{csrf_field()}}
			@include('category._form')
		</form>
	</div>
@endsection