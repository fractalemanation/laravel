@extends('layouts.app')

@section('content')
	<div class="container">
		<a href="{{route('role.index')}}" class="btn btn-primary">Назад</a>
		<hr>
		<ul>
			<li>Наименование: {{$role->name or ''}}</li>
			<li>Slug: {{$role->slug or ''}}</li>
			<li>Пользователи: {{$role->users()->pluck('name')->implode(', ')}}</li>
		</ul>
	</div>
@endsection