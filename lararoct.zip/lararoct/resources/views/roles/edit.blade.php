@extends('layouts.app')

@section('content')
	
	<div class="container">
		<form class="form-horizontal" action="{{route('role.update', $role) }}" method="post">
			<input type="hidden" name="_method" value="put">
		  {{ csrf_field() }}
			<fieldset class="form-horizontal">
			  <div class="form-group"><label class="col-sm-2 control-label">Наименование:</label>
			    <div class="col-sm-10">
			      <input type="text" name="name" class="form-control" value="{{$role->name or ''}}">
			    </div>
			  </div>
			  <div class="form-group"><label class="col-sm-2 control-label">Slug:</label>
			    <div class="col-sm-10">
			      <input type="text" name="slug" class="form-control" value="{{$role->slug or ''}}">
			    </div>
			  </div>
			  <div class="form-group">
			    <div class="col-sm-4 col-sm-offset-2">
			      <button class="btn btn-primary" type="submit">Сохранить</button>
			    </div>
			  </div>
		  	</fieldset>
		</form>
	</div>

@endsection