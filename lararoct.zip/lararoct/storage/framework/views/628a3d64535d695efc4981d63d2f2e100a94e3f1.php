<?php $__env->startSection('content'); ?>
	
	<div class="container">
		<form class="form-horizontal" action="<?php echo e(route('article.update', $article)); ?>" method="post">
			<input type="hidden" name="_method" value="put">
			<?php echo e(csrf_field()); ?>

			<fieldset class="form-horizontal">
			  <div class="form-group"><label class="col-sm-2 control-label">Заголовок:</label>
			    <div class="col-sm-10">
			      <input type="text" name="title" class="form-control" placeholder="" value="<?php echo e(isset($article->title) ? $article->title : ''); ?>">
			    </div>
			  </div>
			  <div class="form-group"><label class="col-sm-2 control-label">Описание:</label>
			    <div class="col-sm-10">
			      <input type="text" name="description" class="form-control" placeholder="" value="<?php echo e(isset($article->description) ? $article->description : ''); ?>">
			    </div>
			  </div>
			  <div class="form-group">
			    <div class="col-sm-4 col-sm-offset-2">
			      <button class="btn btn-primary" type="submit">Сохранить</button>
			    </div>
			  </div>
		  	</fieldset>
		</form>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>