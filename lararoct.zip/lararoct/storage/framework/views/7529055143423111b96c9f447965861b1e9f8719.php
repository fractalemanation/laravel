<?php $__env->startSection('content'); ?>
	
	<div class="container">
		<form class="form-horizontal" action="<?php echo e(route('user.update', $user)); ?>" method="post">
			<input type="hidden" name="_method" value="put">
		  <?php echo e(csrf_field()); ?>

			<fieldset class="form-horizontal">
			  <div class="form-group"><label class="col-sm-2 control-label">Имя:</label>
			    <div class="col-sm-10">
			      <input type="text" name="name" class="form-control" placeholder="" value="<?php echo e(isset($user->name) ? $user->name : ''); ?>">
			    </div>
			  </div>
			  <div class="form-group"><label class="col-sm-2 control-label">E-mail:</label>
			    <div class="col-sm-10">
			      <input type="text" name="email" class="form-control" placeholder="" value="<?php echo e(isset($user->email) ? $user->email : ''); ?>">
			    </div>
			  </div>
			  <div class="form-group"><label class="col-sm-2 control-label">Пароль:</label>
			    <div class="col-sm-10">
			      <input type="password" name="password" class="form-control" placeholder="" value="">
			    </div>
			  </div>
			  <div class="form-group"><label class="col-sm-2 control-label">Животное:</label>
			    <div class="col-sm-10">
			      <input type="text" name="name_animal" class="form-control" placeholder="" value="<?php echo e(isset($user->animal->name_animal) ? $user->animal->name_animal : ''); ?>">
			    </div>
			  </div>
			  <div class="form-group"><label class="col-sm-2 control-label">Роли:</label>
			    <div class="col-sm-10">
			    	<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    		<input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>"
			    		<?php if($user->roles->where('id', $role->id)->count()): ?>
			    			checked="checked"
			    		<?php endif; ?>
			    		>
			    		<label class=""><?php echo e(ucfirst($role->name)); ?></label>
			    		<br>
			    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    </div>
			  </div>
			  <div class="form-group">
			    <div class="col-sm-4 col-sm-offset-2">
			      <button class="btn btn-primary" type="submit">Сохранить</button>
			    </div>
			  </div>
		  	</fieldset>
		</form>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>