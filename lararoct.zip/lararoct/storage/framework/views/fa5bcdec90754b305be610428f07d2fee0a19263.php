<div class="form-group">
	<input type="text" class="form-control" name="title" value="<?php echo e($ticket->title ?? ''); ?>" placeholder="Наименование категории">
</div>
<div class="form-group">
	<select name="categories[]" multiple="" class="form-control">
		<?php echo $__env->make('ticket._categories', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</select>
</div>
<hr>
<button type="submit" class="btn btn-primary">Сохранить</button>