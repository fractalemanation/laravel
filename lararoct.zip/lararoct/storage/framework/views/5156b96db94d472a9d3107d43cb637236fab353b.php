<?php $__env->startSection('content'); ?>
	<div class="container">
		<form action="<?php echo e(route('category.update', $category)); ?>" method="post">
			<?php echo e(method_field('PUT')); ?>

			<?php echo e(csrf_field()); ?>

			<?php echo $__env->make('category._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>