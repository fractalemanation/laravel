<?php $__env->startSection('content'); ?>
	<div class="container">
		<a href="<?php echo e(route('country.index')); ?>" class="btn btn-primary">Назад</a>
		<hr>
		<h1><?php echo e(isset($country->name) ? $country->name : ''); ?></h1>
		<small>Кол-во советов: <?php echo e($country->advice->count()); ?></small>
		<hr>
		<?php $__empty_1 = true; $__currentLoopData = $country->advices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="alert alert-primary" role="alert">
				<b><?php echo e(isset($advice->note->title) ? $advice->note->title : ''); ?></b>
				<hr>
				Советы к заметке:
				<br>
				<i><?php echo e(isset($advice->text) ? $advice->text : ''); ?></i>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<h3 class="text-center">Советов нет</h3>
			<?php endif; ?>
			</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>