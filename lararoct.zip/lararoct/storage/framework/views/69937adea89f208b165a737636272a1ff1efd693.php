<?php $__env->startSection('content'); ?>
	<div class="container">
		<a href="<?php echo e(route('note.index')); ?>" class="btn btn-primary">Назад</a>
		<hr>
		<h1><?php echo e(isset($note->title) ? $note->title : ''); ?></h1>
		<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($note->country_id == $country->id): ?>
				<?php echo e($country->name); ?>

			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<hr>
		<?php $__empty_1 = true; $__currentLoopData = $note->advices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="alert alert-primary" role="alert">
				<?php echo e(isset($advice->text) ? $advice->text : ''); ?>

				<p class="mb-0">
					<a class="btn btn-primary" href="<?php echo e(route('advice.edit', $advice)); ?>">Редактировать</a>
				</p>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<h3 class="text-center">Комментариев нет</h3>
		<?php endif; ?>
		<form class="form-horizontal" action="<?php echo e(route('advice.store')); ?>" method="post">
			<input type="hidden" name="note_id" value="<?php echo e(isset($note->id) ? $note->id : ''); ?>">
			<?php echo e(csrf_field()); ?>

			<fieldset class="form-horizontal">
				<div class="form-group">
					<label class="col-sm-1 control-label">Комментарий:</label>
					<div class="col-sm-12">
						<textarea name="text" class="form-control"></textarea>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-4">
						<button class="btn btn-primary" type="submit">Опубликовать</button>
					</div>
				</div>
			</fieldset>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>