<?php $__env->startSection('content'); ?>
	<div class="container">
		<a href="<?php echo e(route('user.index')); ?>" class="btn btn-primary">Назад</a>
		<hr>
		<ul>
			<li>Name: <?php echo e(isset($user->name) ? $user->name : ''); ?></li>
			<li>Email: <?php echo e(isset($user->email) ? $user->email : ''); ?></li>
			<li>Animal: <?php echo e(isset($user->animal->name_animal) ? $user->animal->name_animal : ''); ?></li>
			<li>Role: <?php echo e($user->roles()->pluck('name')->implode(', ')); ?>

			
			</li>
		</ul>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>