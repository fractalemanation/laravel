<?php $__env->startSection('content'); ?>
	<div class="container">
		<a href="<?php echo e(route('article.index')); ?>" class="btn btn-primary">Назад</a>
		<hr>
		<h1><?php echo e(isset($article->title) ? $article->title : ''); ?></h1>
		<p><?php echo e(isset($article->description) ? $article->description : ''); ?></p>
		<hr>
		<?php $__empty_1 = true; $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="alert alert-primary" role="alert">
				<?php echo e(isset($comment->text) ? $comment->text : ''); ?>

				<p class="mb-0">
					<a class="btn btn-primary" href="<?php echo e(route('comment.edit', $comment)); ?>">Редактировать</a>
				</p>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<h3 class="text-center">Комментариев нет</h3>
		<?php endif; ?>
		<form class="form-horizontal" action="<?php echo e(route('comment.store')); ?>" method="post">
			<input type="hidden" name="article_id" value="<?php echo e(isset($article->id) ? $article->id : ''); ?>">
			<?php echo e(csrf_field()); ?>

			<fieldset class="form-horizontal">
				<div class="form-group">
					<label class="col-sm-1 control-label">Комментарий:</label>
					<div class="col-sm-12">
						<textarea name="text" class="form-control"></textarea>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-4">
						<button class="btn btn-primary" type="submit">Опубликовать</button>
					</div>
				</div>
			</fieldset>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>