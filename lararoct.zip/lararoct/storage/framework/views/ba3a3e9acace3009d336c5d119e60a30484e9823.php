<?php $__env->startSection('content'); ?>
	<div class="container">
		<a href="<?php echo e(route('user.index')); ?>" class="btn btn-primary">Назад</a>
		<hr>
		<ul>
			<li>Animal: <?php echo e(isset($animal->name_animal) ? $animal->name_animal : ''); ?></li>
			<li>User name: <?php echo e(isset($animal->user->name) ? $animal->user->name : ''); ?></li>
			<li>User email: <?php echo e(isset($animal->user->email) ? $animal->user->email : ''); ?></li>
		</ul>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>