<?php $__env->startSection('content'); ?>
	<div class="container">
		<a href="<?php echo e(route('role.index')); ?>" class="btn btn-primary">Назад</a>
		<hr>
		<ul>
			<li>Наименование: <?php echo e(isset($role->name) ? $role->name : ''); ?></li>
			<li>Slug: <?php echo e(isset($role->slug) ? $role->slug : ''); ?></li>
			<li>Пользователи: <?php echo e($role->users()->pluck('name')->implode(', ')); ?></li>
		</ul>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>