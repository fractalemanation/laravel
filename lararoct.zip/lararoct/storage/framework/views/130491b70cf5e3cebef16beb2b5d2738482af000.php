<div class="form-group">
	<input type="text" class="form-control" name="title" value="<?php echo e($category->title ?? ''); ?>" placeholder="Наименование категории">
</div>
<div class="form-group">
	<select name="parent_id" class="form-control">
		<option value="0">-- без родительской категории --</option>
		<?php echo $__env->make('category._categories', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</select>
</div>
<hr>
<button type="submit" class="btn btn-primary">Сохранить</button>