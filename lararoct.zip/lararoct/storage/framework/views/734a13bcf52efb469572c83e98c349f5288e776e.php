<?php $__env->startSection('content'); ?>
	<div class="container">
		<h3>Комментарий к статье: <?php echo e(isset($comment->article->title) ? $comment->article->title : ''); ?></h3>
		<form class="form-horizontal" action="<?php echo e(route('comment.update', $comment)); ?>" method="post">
			<?php echo e(method_field('PUT')); ?>

			<?php echo e(csrf_field()); ?>

			<fieldset class="form-horizontal">
				<div class="form-group"><label class="col-sm-2 control-label">Описание:</label>
					<div class="col-sm-10"><textarea name="text" class="form-control"><?php echo e(isset($comment->text) ? $comment->text : ''); ?></textarea></div>
				</div>
				<div class="form-group">
					<div class="col-sm-4 col-sm-offset-2"><button class="btn btn-primary" type="submit">Сохранить</button></div>
				</div>
			</fieldset>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>