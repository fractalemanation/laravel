<?php $__env->startSection('content'); ?>
	<div class="container">
		<a class="btn btn-primary" href="<?php echo e(route('ticket.create')); ?>">Создать</a>
		<hr>
		<table class="table">
			<thead>
				<tr>
					<th>Наименование</th>
					<th class="text-right">Действие</th>
				</tr>
			</thead>
			<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td><?php echo e($ticket->title ?? ''); ?></td>
						<td class="text-right">
							<a class="btn btn-primary" href="<?php echo e(route('ticket.edit', $ticket)); ?>">Редактировать</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<tr>
						<td colspan="2">
							<h1 class="text-center">Категории отсутствуют</h1>
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>