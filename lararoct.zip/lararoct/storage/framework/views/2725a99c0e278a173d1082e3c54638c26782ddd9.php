<?php $__env->startSection('content'); ?>
	<div class="container">
		<a href="<?php echo e(route('role.create')); ?>" class="btn btn-primary">Создать</a>
		<a href="<?php echo e(route('user.index')); ?>" class="btn btn-default">Пользователи</a>
		
		<hr>

		<table class="footable table table-stripped toggle-arrow-tiny" data-page-size="15">
		  <thead>
		    <tr>
		      <th data-toggle="true">Наименование</th>
		      <th data-toggle="true">Slug</th>
		      <th data-hide="phone">Пользователи</th>
		      <th class="text-right" data-sort-ignore="true">Действие</th>
		    </tr>
		  </thead>
		  <tbody>
		    <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		      <tr>
		        <td><?php echo e($role->name); ?></td>
		        <td><?php echo e($role->slug); ?></td>
		        <td><?php echo e($role->users()->pluck('name')->implode(', ')); ?></td><!--pluck() - извлекает все значения по заданому ключу-->
		        <td class="text-right">
		          <form onsubmit="if(confirm('Удалить?')){ return true }else{ return false }" action="<?php echo e(route('role.destroy', $role)); ?>" method="post">
		            <input type="hidden" name="_method" value="DELETE">
		            <?php echo e(csrf_field()); ?>

		            <div class="btn-group">
		              <a class="btn btn-primary" href="<?php echo e(route('role.edit', $role)); ?>">Редактировать</a>
		              <button type="submit" class="btn btn-danger">Удалить</button>
		            </div>
		          </form>
		        </td>
		      </tr>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		      <tr>
		        <td colspan="5" class="text-center">
		          <h2 class="ui center aligned icon header" class="center aligned">
		            <i class="circular database icon"></i>
		            Данные отсутствуют
		          </h2>
		        </td>
		      </tr>
		    <?php endif; ?>

		  </tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>