<?php $__env->startSection('content'); ?>
<div class="container">
	<!--<h1>Загрузка файла вариант 1</h1>
	<form method="post" enctype="multipart/form-data" action="<?php echo e(route('image.upload')); ?>">
		<?php echo e(csrf_field()); ?>

		<div class="form-group">
			<input type="file" name="image">
		</div>
		<button class="btn btn-default" type="submit">Загрузка</button>
	</form>
	<?php if(isset($path)): ?>
	<br><img class="img-responsive" src="<?php echo e(asset('/storage/'.$path)); ?>">
	<?php endif; ?>-->
	<h1>Загрузка файла вариант 2</h1>
	<image-upload></image-upload>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>