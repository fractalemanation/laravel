<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Advice extends Model
{
    protected $guarded = [];

    public function notes () {
    	return $this->belongsTo('App\Note');
    }
}
