<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    protected $guarded = [];

    public function advices () {
    	return $this->hasManyThrough('App\Advice', 'App\Note');//hasManyThrough('App\Advice', 'App\Note', 'country_id', 'note_id', 'id_note', 'id_country')
    }

    public function notes () {
    	return $this->hasMany('App\Note');
    }
}
