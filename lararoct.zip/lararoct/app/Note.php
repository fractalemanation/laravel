<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Note extends Model
{
    protected $guarded = [];
    
    public function advices () {
    	return $this->hasMany('App\Advice');
    }

    public function countries () {
    	return $this->belongsTo('App\Country');
    }
}
