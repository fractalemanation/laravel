<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
	protected $guarded = [];//разрешить заполнять все поля
	
    public function categories() {
    	return $this->belongsToMany('App\Category');
    }
}
