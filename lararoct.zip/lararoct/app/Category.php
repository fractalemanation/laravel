<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
	protected $guarded = [];//разрешить заполнять все поля

	public function children() {
		return $this->hasMany(self::class, 'parent_id');//Отношение один ко многим внутри таблицы
	}
}
