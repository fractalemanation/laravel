<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCategoryTicketTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('category_ticket', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('ticket_id')->unsigned();//Число не может быть отрицательным
            $table->foreign('ticket_id')->references('id')->on('tickets')->onDelete('cascade');//Удалить автоматически связи
            $table->integer('category_id')->unsigned();
            $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('category_ticket', function (Blueprint $table) {
            $table->dropForeign('category_ticket_category_id_foreign');//['category_id'] - сокращеный вид записи; Удаляем внешний ключ
            $table->dropForeign('category_ticket_ticket_id_foreign');
        });//Schema::table - метод для обновления таблицы
        Schema::dropIfExists('category_ticket');
    }
}
