<template>
    <div class="container">
        <div class="row">
            <table class="table">
                <thead>
                    <tr>
                        <th>Наименование</th>
                        <th>URL</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="url in urldata">
                        <td>{{url.title}}</td>
                        <td>{{url.url}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
    export default {
        props: [
        'urldata'//Можно получить любой входной параметр
        ],
        mounted() {
            this.update()
        },
        methods: {
            update: function () {
            console.log(this.urldata);
            }
        }
    }
</script>
