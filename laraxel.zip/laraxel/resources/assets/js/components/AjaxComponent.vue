<template>
    <div class="container">
        <div class="row">
            <button v-on:click="update" class="btn btn-default text mb-1" v-if="!is_refresh">Обновить - {{id}}</button>
            <span class="badge badge-primary mb-1" v-if="is_refresh">Обновление</span>
            <table class="table">
                <thead>
                    <tr>
                        <th>Наименование</th>
                        <th>URL</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="url in urldata">
                        <td>{{url.title}}</td>
                        <td>{{url.url}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
    export default {
        data: function () {
            return {
                urldata: [],
                is_refresh: false,
                id: 0
            }
        },//В файле vue data имеет функцию, чтобы каждый экземпляр компонента мог управлять собственной копией возвращаемого обьекта данных
        mounted() {
            this.update();
        },
        methods: {
            update: function () {
                this.is_refresh = true;
                //var app = this;//Если бы использовали не стрелочную функцию, так как обычная функция имеет свой контекст
                axios.get('/start/get-json').then((response) => {
                    console.log(response);
                    this.urldata = response.data;
                    this.is_refresh = false;
                    this.id++;
                });
            }
        }
    }
</script>
