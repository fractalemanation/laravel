<template>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <line-chart v-bind:chart-data="data" v-bind:height="100" v-bind:options="{responsive: true, maintainAspectRation: true}"></line-chart>
                <button v-on:click="update" class="btn btn-primary btn-xs mt-1 mh-10">Обновить</button>
            </div>
        </div>
    </div>
</template>

<script>
    import LineChart from './LineChart.js'
    export default {
        components: {
            LineChart
        },
        data: function () {
            return {
                data: []
            }
        },
        mounted() {
            this.update();
        },
        methods: {
            update: function () {
                this.is_refresh = true;
                axios.get('/start/random-chart').then((response) => {
                    this.data = response.data;
                });
            }
        }
    }
</script>