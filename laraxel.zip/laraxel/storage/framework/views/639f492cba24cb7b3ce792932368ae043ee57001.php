<?php $__env->startSection('content'); ?>
<h1 class="text-center">Vue</h1>
<prop-component v-bind:urldata="<?php echo e(json_encode($url_data)); ?>"></prop-component>

<h1 class="text-center">Ajax</h1>
<ajax-component></ajax-component>

<h1 class="text-center">ChartLine</h1>
<chartline-component></chartline-component>

<h1 class="text-center">ChartPie</h1>
<chartpie-component></chartpie-component>

<h1 class="text-center">ChartRandom</h1>
<chartrandom-component></chartrandom-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>