-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июл 03 2019 г., 13:52
-- Версия сервера: 5.7.23
-- Версия PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `clean`
--

-- --------------------------------------------------------

--
-- Структура таблицы `calculators`
--

CREATE TABLE `calculators` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `calculators`
--

INSERT INTO `calculators` (`id`, `title`) VALUES
(1, 'Стандартная'),
(2, 'Генеральная'),
(3, 'Окна');

-- --------------------------------------------------------

--
-- Структура таблицы `fields`
--

CREATE TABLE `fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `calculator_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `fields`
--

INSERT INTO `fields` (`id`, `title`, `price`, `type`, `calculator_id`) VALUES
(1, 'Комната', 350, 1, 1),
(2, 'Санузел', 200, 1, 1),
(3, 'Кухня', 200, 2, 1),
(4, 'Пылесос', 0, 2, 1),
(5, 'Комната', 400, 1, 2),
(6, 'Санузел', 250, 1, 2),
(7, 'Окно', 100, 1, 2),
(8, 'Балкон', 150, 1, 2),
(9, 'Кухня', 300, 2, 2),
(10, 'Пылесос', 0, 2, 2),
(11, 'Окно', 100, 1, 3),
(12, 'Балкон', 150, 1, 3),
(13, '2 стороны', 2, 2, 3),
(14, 'Подоконники', 40, 2, 3),
(15, 'Рама', 30, 2, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `generals`
--

CREATE TABLE `generals` (
  `id` int(10) UNSIGNED NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `generals`
--

INSERT INTO `generals` (`id`, `description`, `type`) VALUES
(1, 'Описание', 'main'),
(2, 'Наша компания предлагает полный комплекс услуг по профессиональной уборке квартир в Сумах. Высококвалифицированные специалисты, профессиональное оснащение, эффективная организация сервиса позволяют получить оптимальное сочетание цены и качества. Всего несколько часов нашей работы, и ваша квартира приобретет идеальную свежесть и чистоту.', 'main'),
(3, 'Наши услуги', 'main'),
(4, 'Благодарность', 'main'),
(5, 'Мы благодарим Вас за обращение!', 'main'),
(6, 'Закрыть', 'main'),
(7, 'Отзывы', 'main'),
(8, 'Оставить отзыв', 'main'),
(9, 'Отправить', 'main'),
(10, 'Несем ответственность', 'main'),
(11, 'Возместим ущерб, если с вашим имуществом что-то произойдет.', 'main'),
(12, 'Лучшая цена', 'main'),
(13, 'На сегодня у нас самое выгодное предложение на рынке в городе Сумы.', 'main'),
(14, 'Несколько способов оплаты на выбор', 'main'),
(15, 'Выбирайте, как  удобнее оплатить услуги –  наличными или картой.', 'main'),
(16, 'Уборка в день оформления заказа', 'main'),
(17, 'Оставьте заявку прямо сейчас, и мы приедем уже сегодня.', 'main'),
(18, 'Наша команда', 'main'),
(19, 'Мы ответственно относимся к подбору специалистов и проводим обучение каждого нового сотрудника. Вы всегда можете оставить отзыв и рассказать, что вам понравилось в работе клинера, а что могло бы быть лучше.', 'main'),
(20, 'Анна', 'main'),
(21, '4.7|223 оценок', 'main'),
(22, 'Наталья', 'main'),
(23, '4.6|227 оценок', 'main'),
(24, 'Ксения', 'main'),
(25, '4.5|215 оценок', 'main'),
(26, 'Частые вопросы', 'main'),
(27, 'Требуется ли мое присутствие во время уборки?', 'main'),
(28, 'Вы сами решаете, остаться в квартире или заняться своими делами. В зависимости от объема работ мы рассчитываем время на уборку, поэтому до назначенного часа сдачи вы можете распорядиться временем по своему усмотрению.', 'main'),
(29, 'Уборщик приезжает с необходимыми средствами и инвентарем?', 'main'),
(30, 'Да, специалист приедет со всем необходимым. Если у вас в квартире есть ковролин или ковры, пожалуйста, предоставьте пылесос. Все остальные инструменты и чистящие средства мы привезем с собой.', 'main'),
(31, 'Есть ли у вас возможность помыть потолки, верхние поверхности шкафов, люстры и другие труднодоступные места?', 'main'),
(32, 'Да, мы готовы выполнить подобные работы, если вы предоставите клинеру стремянку. Со стандартным оснащением выполнять очистку высокорасположенных поверхностей, к сожалению, не получится.', 'main'),
(33, '+38 (050) 350-30-90', 'phone'),
(34, 'Понедельник - Суббота (8:00 - 22:00)', 'schedule'),
(35, 'reseticleaner@gmail.com', 'mail');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_06_23_093514_create_calculators_table', 1),
(4, '2019_06_23_093535_create_fields_table', 1),
(5, '2019_06_23_113310_create_services_table', 1),
(6, '2019_06_24_144211_create_generals_table', 1),
(7, '2019_06_30_144532_create_reviews_table', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `show` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `name`, `message`, `show`) VALUES
(1, 'Дмитрий', 'Хочу выразить благодарность за качественно выполненную генеральную уборку квартиры. Хотел бы отметить лояльность цен на услуги.', 1),
(2, 'Светлана', 'Хочу выразить благодарность за качественно выполненную генеральную уборку квартиры. Хотел бы отметить лояльность цен на услуги.', 1),
(3, 'Анна', 'Хочу выразить благодарность за качественно выполненную генеральную уборку квартиры. Хотел бы отметить лояльность цен на услуги.', 1),
(4, 'Евгений', 'Хочу выразить благодарность за качественно выполненную генеральную уборку квартиры. Хотел бы отметить лояльность цен на услуги.', 1),
(5, 'Олег', 'Хочу выразить благодарность за качественно выполненную генеральную уборку квартиры. Хотел бы отметить лояльность цен на услуги.', 1),
(6, 'Наталья', 'Хочу выразить благодарность за качественно выполненную генеральную уборку квартиры. Хотел бы отметить лояльность цен на услуги.', 1),
(7, 'Людмила', 'Хочу выразить благодарность за качественно выполненную генеральную уборку квартиры. Хотел бы отметить лояльность цен на услуги.', 1),
(8, 'Геннадий', 'Хочу выразить благодарность за качественно выполненную генеральную уборку квартиры. Хотел бы отметить лояльность цен на услуги.', 1),
(9, 'Александр', 'Хочу выразить благодарность за качественно выполненную генеральную уборку квартиры. Хотел бы отметить лояльность цен на услуги.', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `services`
--

CREATE TABLE `services` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `services`
--

INSERT INTO `services` (`id`, `title`, `parent_id`) VALUES
(1, 'Стандартная', 0),
(2, 'В комнатах', 1),
(3, 'Пылесосим ковры и коврики', 2),
(4, 'Моем пол', 2),
(5, 'Протираем все поверхности', 2),
(6, 'Чистим зеркала стеклянные поверхности', 2),
(7, 'Кухня', 1),
(8, 'Моем раковину', 7),
(9, 'Протираем кухонный стол и столешницы', 7),
(10, 'Чистим плиту (сверху), Протираем холодильник и вытяжку', 7),
(11, 'Протираем все поверхности', 7),
(12, 'Ванная', 1),
(13, 'Чистим унитаз', 12),
(14, 'Моем раковину', 12),
(15, 'Генеральная', 0),
(16, 'В комнатах', 15),
(17, 'Пылесосим ковры и коврики', 16),
(18, 'Моем пол', 16),
(19, 'Протираем все поверхности', 16),
(20, 'Чистим зеркала стеклянные поверхности', 16),
(21, 'Протираем подоконники', 16),
(22, 'Моем коридор', 16),
(23, 'Кухня', 15),
(24, 'Моем посуду', 23),
(25, 'Моем раковину', 23),
(26, 'Протираем все поверхности', 23),
(27, 'Моем плиту (снаружи и внутри), холодильники (снаружи и внутри) и вытяжку (снаружи)', 23),
(28, 'Вымоем духовку и микроволновку внутри', 23),
(29, 'Моем кухонную мебель изнутри и снаружи', 23),
(30, 'Собираем и выносим мусор', 23),
(31, 'Ванная', 15),
(32, 'Моем ванну', 31),
(33, 'Моем душевую кабину', 31),
(34, 'Моем раковину', 31),
(35, 'Моем и дезинфицируем унитаз', 31),
(36, 'Моем столешницы', 31),
(37, 'Что мы не делаем', 0),
(38, 'Не работаем во дворах и огородах', 37),
(39, 'Не переставляем мебель', 37),
(40, 'Не работаем грузчиками', 37),
(41, 'Не делаем химчистку ковров', 37),
(42, 'Не работаем курьерами', 37),
(43, 'Не нянчим детей', 37);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `calculators`
--
ALTER TABLE `calculators`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `fields`
--
ALTER TABLE `fields`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `generals`
--
ALTER TABLE `generals`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `calculators`
--
ALTER TABLE `calculators`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `fields`
--
ALTER TABLE `fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `generals`
--
ALTER TABLE `generals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `services`
--
ALTER TABLE `services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
