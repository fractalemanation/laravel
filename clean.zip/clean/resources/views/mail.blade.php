@foreach ($data as $key => $value)
	<h1>
		@if ($value)
			@if ($key == 'phone')
				Номер телефона: {{$value}}
			@elseif ($key == 'address')
				Адрес: {{$value}}
			@elseif ($key == 'name')
				Имя: {{$value}}
			@elseif ($key == 'type')
				Уборка: {{$value}}
			@elseif ($key == 'room')
				Количество комнат: {{$value}}
			@elseif ($key == 'bathroom')
				Количество санузлов: {{$value}}
			@elseif ($key == 'window')
				Количество окон: {{$value}}
			@elseif ($key == 'balcony')
				Количество балконов: {{$value}}
			@elseif ($key == 'kitchen')
				Кухня
			@elseif ($key == 'vacuum')
				Пылесос
			@elseif ($key == 'side')
				Окна с двух сторон
			@elseif ($key == 'sill')
				Подоконники
			@elseif ($key == 'frame')
				Рамки
			@elseif ($key == 'price')
				Цена: {{$value}}
			@endif
		@endif
	</h1>
@endforeach