@extends('layouts.app')

@section('content')
<!--<div class="main-block container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="calculator-block col-md-4 text-center">
                <h1 class="title-calculator-main col-md-12">УБОРКА</h1>
                @foreach ($сalculators as $calculator)
	                <div>
	                    <button class="btn btn-default btn-calculator-type col-xs-12 col-md-4 text-uppercase" v-on:click="show = {{$calculator->id}}">{{$calculator->title}}</button>
	                </div>
	            @endforeach
	            @foreach ($сalculators as $calculator)
	                <div>
	                    <div v-if="show === {{$calculator->id}}">
	                        <h1 class="title-calculator col-md-12 text-uppercase">{{$calculator->title}}</h1>
	                    </div>
	                </div>
	            @endforeach
            </div>
        </div>
    </div>
</div>
@foreach ($сalculators as $calculator)
  {{$calculator->title}}
  @isset ($calculator->fields)
      @foreach ($calculator->fields as $field)
        {{$field->title}}
      @endforeach
  @endisset
@endforeach-->
<div id="congratulations" class="modal fade" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button class="close" data-dismiss="modal">х</button>
        <h4 class="modal-title text-center">{{$general[3]->description}}</h4>
      </div>
      <div class="modal-body text-center">
        <h3>{{$general[4]->description}}</h3>
      </div>
      <div class="modal-footer">
        <button class="btn btn-default btn-block" data-dismiss="modal">{{$general[5]->description}}</button>
      </div>
    </div>
  </div>
</div>
<main-component :calculators="{{$сalculators}}"></main-component>
<div class="container general-text">
  <h1 class="text-center">{{$general[0]->description}}</h1>
	<p class="text-center">{{$general[1]->description}}</p>
</div>
<div class="container service text-center">
    <h1>{{$general[2]->description}}</h1>
		<div class="row services">
      @include('layouts.services')
    </div>
</div>
<div class="container-fluid reviews-background text-center">
  <h1>{{$general[6]->description}}</h1>
  <div class="container">
    <div class="row reviews">
      @foreach ($reviews as $review)
        <div class="col-md-4">
          <div>
            <h2>{{$review->name}}</h2>
            <p>{{$review->message}}</p>
          </div>
        </div>
      @endforeach
    </div>
  </div>
</div>
<div class="container">
  <h1 class="text-center">{{$general[7]->description}}</h1>
  <form class="form-horizontal feedback" action="/feedback" method="post">
    {{ csrf_field() }}
    <fieldset class="form-horizontal">
      <div class="form-group">
        <div class="col-sm-12">
          <input type="text" name="name" class="form-control" placeholder="Имя">
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-12">
          <textarea name="message" class="form-control" rows="10" placeholder="Отзыв"></textarea>
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-12">
          <button class="btn btn-default btn-md btn-block" type="submit">{{$general[8]->description}}</button>
        </div>
      </div>
    </fieldset>
  </form>
</div>
@endsection