@foreach ($services as $service)
    @if ($service->children->count())
        @if ($service->parent_id == 0)
            <div class="col-md-4">
                <div class="panel panel-primary">
                    <div class="panel-heading"><h2>{{$service->title ?? ''}}</h2></div>
                    <div class="panel-body">@include('layouts.services', ['services' => $service->children, 'is_child' => true])</div>
                </div>
            </div>
        @else
            <h3>{{$service->title ?? ''}}</h3>
            <ul class="col-md-12">
                @include('layouts.services', ['services' => $service->children, 'is_child' => true])
            </ul>
        @endif
    @else
        @isset($is_child)
            <li>{{$service->title ?? ''}}</li>
            @continue
        @endisset
    @endif
@endforeach