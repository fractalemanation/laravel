<?php

/*
|--------------------------------------------------------------------------
| Broadcast Channels
|--------------------------------------------------------------------------
|
| Here you may register all of the event broadcasting channels that your
| application supports. The given channel authorization callbacks are
| used to check if an authenticated user can listen to the channel.
|
*/

/*Broadcast::channel('App.User.{id}', function ($user, $id) {
    return (int) $user->id === (int) $id;
});*/

Broadcast::channel('room.{room_id}', function ($user, $room_id) {
    //return (int) $user->id === (int) $id;
    //return (int) $user->id === 1;
    return true;
});
Broadcast::channel('arbor.{room_id}', function ($user, $room_id) {
    return $user->rooms->contains($room_id);//contains ищет значение в коллекции
    /*if ($user->rooms->contains($room_id)) {
    	return $user->name;//Каждый пользователь сможет получить список участников
    }*/
});