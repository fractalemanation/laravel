<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class PublicChat implements ShouldBroadcast//событие широковещательное
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $message;//информацию которую передадим

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($message)
    {
        $this->message = $message;
    }//Заполняем переменную информацией которую передали

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new Channel('public-chat');
    }//возвращает массив каналов для которого событие должно быть широковещательным
}//Событие это контейнер данных который содержит массив данных относящихся к событию
