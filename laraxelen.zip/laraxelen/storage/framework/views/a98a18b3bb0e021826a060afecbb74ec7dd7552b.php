<?php $__env->startSection('content'); ?>
	<chat-component></chat-component>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\OSPanel\domains\laraxelen\resources\views/chat.blade.php ENDPATH**/ ?>