<?php $__env->startSection('content'); ?>
	<?php if(Auth::check()): ?>
		<room-chat-component :room="<?php echo e($room); ?>" :user="<?php echo e(Auth::user()); ?>"></room-chat-component>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\OSPanel\domains\laraxelen\resources\views/room.blade.php ENDPATH**/ ?>