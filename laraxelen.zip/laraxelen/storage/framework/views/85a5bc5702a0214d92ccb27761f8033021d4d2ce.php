<?php $__env->startSection('content'); ?>
	<private-chat-component></private-chat-component>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\OSPanel\domains\laraxelen\resources\views/private.blade.php ENDPATH**/ ?>