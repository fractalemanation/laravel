<template>
    <div class="container">
        <center>Need 2 tabs for Laravel Echo</center>
    </div>
</template>

<script>
    export default {
        mounted() {
            window.Echo.channel('public-chat').listen('PublicChat', (e) => {
                document.write("<center>"+e.message+"</center>");
                console.log(e);
            });
        }
    }
</script>