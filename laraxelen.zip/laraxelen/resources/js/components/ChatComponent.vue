<template>
    <div class="container">
        <hr>
        <div class="row">
            <div class="col-sm-12">
                <textarea class="form-control" rows="10" readonly="">{{messages.join('\n')}}</textarea>
                <hr>
                <input type="text" class="form-control" v-model="textMessage" v-on:keyup.enter="sendMessage">
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data () {
            return {
                messages: [],
                textMessage: ''
            }
        },
        mounted() {
            /*window.Echo.channel('chat').listen('Message', (e) => {
                this.messages.push(e.message);
            });*/
            window.Echo.channel('chat').listen('Message', ({message}) => {
                this.messages.push(message);//если $request->all(), то нужно было бы писать message.body, то есть обращались бы к элементу
            });
        },
        methods: {
            sendMessage () {
                axios.post('/messages', { body: this.textMessage });
                this.messages.push(this.textMessage);
                this.textMessage = '';
            }
        }
    }
</script>