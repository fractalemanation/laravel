@extends('layouts.app')
@section('content')
	@if (Auth::check())
		<room-chat-component :room="{{$room}}" :user="{{Auth::user()}}"></room-chat-component>
	@endif
@endsection