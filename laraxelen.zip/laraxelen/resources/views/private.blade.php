@extends('layouts.app')
@section('content')
	<private-chat-component></private-chat-component>
@endsection